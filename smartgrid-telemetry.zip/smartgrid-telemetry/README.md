# SmartGrid Telemetry (UTS Pemrograman Jaringan)

Prototipe komunikasi **Client–Server** berbasis **TCP Socket** dengan **Protocol Buffers (proto3)**
untuk mengirim data telemetri sensor gardu listrik secara ringan (lebih kecil dari JSON).

## Struktur Proyek

| File | Fungsi |
|------|--------|
| `telemetry.proto` | Skema: enum `StatusPerangkat`, message `DataSensor` & `ResponServer` |
| `telemetry_pb2.py` | Kode Python hasil generate dari skema |
| `common.py` | Framing pesan TCP (prefix panjang 4 byte) |
| `server.py` | Aplikasi Server (listen, deserialisasi, peringatan KRITIS, balasan biner) |
| `client.py` | Aplikasi Client (mode simulasi 4 paket / mode interaktif) |

## Cara Menjalankan (VS Code)

1. Buka folder proyek di VS Code, lalu buka terminal (`Ctrl + ~`).
2. (Disarankan) buat virtual environment dan install dependensi:
   ```bash
   python -m venv .venv
   # Windows:  .venv\Scripts\activate
   # Linux/Mac: source .venv/bin/activate
   pip install -r requirements.txt
   ```
3. **Terminal 1 – jalankan Server:**
   ```bash
   python server.py
   ```
4. **Terminal 2 – jalankan Client:**
   ```bash
   python client.py                    # simulasi 4 paket berurutan
   python client.py --mode interaktif  # input manual
   ```
   Opsi tambahan: `--host 127.0.0.1 --port 5050` (untuk jaringan lokal, ganti IP dan jalankan server dengan `--host 0.0.0.0`).

## Generate Ulang `telemetry_pb2.py` (opsional)

```bash
pip install grpcio-tools
python -m grpc_tools.protoc -I. --python_out=. telemetry.proto
```

## Alur Kerja Protokol

1. Client membuat objek `DataSensor` → `SerializeToString()` → kirim `[4 byte panjang][payload biner]`.
2. Server membaca pesan utuh → `ParseFromString()` → tampilkan rincian ke konsol
   (+ peringatan khusus jika `status == KRITIS`).
3. Server membuat `ResponServer` (`diterima`, `pesan_konfirmasi`, `ukuran_byte`) → serialisasi → kirim balik.
4. Client deserialisasi balasan dan menampilkan pesan konfirmasi + ukuran byte.

> TCP adalah byte stream tanpa batas pesan, jadi setiap pesan diberi prefix panjang 4 byte
> agar server tahu kapan satu paket Protobuf selesai.

## Contoh Perbandingan Ukuran Payload

| Paket | Protobuf | JSON |
|-------|----------|------|
| GD-01 (NORMAL) | 31 byte | 94 byte |
| GD-02 (PERINGATAN) | 65 byte | 167 byte |
| GD-03 (KRITIS) | 89 byte | 191 byte |

## Upload ke GitHub

```bash
git init
git add .
git commit -m "UTS Pemrograman Jaringan: SmartGrid Telemetry (Protobuf + TCP)"
git branch -M main
git remote add origin https://github.com/USERNAME/NAMA-REPO.git
git push -u origin main
```
