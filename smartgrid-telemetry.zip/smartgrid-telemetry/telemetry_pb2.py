# -*- coding: utf-8 -*-
# Kode hasil generate dari telemetry.proto (setara output `protoc --python_out`).
# Jika ingin generate ulang dengan protoc resmi, lihat README.md.
# source: telemetry.proto
"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder

_sym_db = _symbol_database.Default()

DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x0ftelemetry.proto\x12\tsmartgrid"\x9d\x01\n\nDataSensor\x12\x11\n\tdevice_id\x18\x01 \x01(\t\x12\x11\n\ttimestamp\x18\x02 \x01(\x03\x12\x15\n\rtegangan_volt\x18\x03 \x01(\x01\x12\x13\n\x0barus_ampere\x18\x04 \x01(\x01\x12*\n\x06status\x18\x05 \x01(\x0e2\x1a.smartgrid.StatusPerangkat\x12\x11\n\tlog_error\x18\x06 \x03(\t"O\n\x0cResponServer\x12\x10\n\x08diterima\x18\x01 \x01(\x08\x12\x18\n\x10pesan_konfirmasi\x18\x02 \x01(\t\x12\x13\n\x0bukuran_byte\x18\x03 \x01(\x05*9\n\x0fStatusPerangkat\x12\n\n\x06NORMAL\x10\x00\x12\x0e\n\nPERINGATAN\x10\x01\x12\n\n\x06KRITIS\x10\x02b\x06proto3')

_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'telemetry_pb2', _globals)
