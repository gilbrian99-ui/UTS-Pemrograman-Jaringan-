"""Helper bersama untuk Client & Server: framing pesan di atas TCP.

TCP adalah *byte stream* (tidak mengenal batas pesan), sehingga setiap
pesan Protobuf diawali 4 byte (big-endian) berisi panjang payload.
"""
import socket
import struct

HEADER_FMT = "!I"                      # 4 byte, unsigned int, big-endian
HEADER_SIZE = struct.calcsize(HEADER_FMT)
MAX_PAYLOAD = 1024 * 1024              # batas aman 1 MB


def recv_exact(sock: socket.socket, n: int) -> bytes:
    """Baca tepat n byte dari socket; kembalikan b'' jika koneksi ditutup."""
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            return b""
        buf += chunk
    return buf


def send_msg(sock: socket.socket, payload: bytes) -> None:
    sock.sendall(struct.pack(HEADER_FMT, len(payload)) + payload)


def recv_msg(sock: socket.socket):
    """Terima satu pesan utuh. Return None jika koneksi ditutup."""
    header = recv_exact(sock, HEADER_SIZE)
    if not header:
        return None
    (length,) = struct.unpack(HEADER_FMT, header)
    if length > MAX_PAYLOAD:
        raise ValueError(f"Payload terlalu besar: {length} byte")
    return recv_exact(sock, length) if length else b""
