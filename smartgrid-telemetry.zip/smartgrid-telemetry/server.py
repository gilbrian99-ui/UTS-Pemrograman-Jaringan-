"""Server SmartGrid Telemetry (TCP Socket + Protocol Buffers).

Jalankan:  python server.py [--host 127.0.0.1] [--port 5050]
"""
import argparse
import socket
import threading
from datetime import datetime

from google.protobuf.message import DecodeError

import telemetry_pb2 as pb
from common import recv_msg, send_msg

LOCK = threading.Lock()  # agar output konsol tidak tercampur antar thread


def log(*args):
    with LOCK:
        print(*args, flush=True)


def tampilkan_data(data: pb.DataSensor, ukuran: int, addr) -> None:
    waktu = datetime.fromtimestamp(data.timestamp).strftime("%Y-%m-%d %H:%M:%S")
    status = pb.StatusPerangkat.Name(data.status)
    with LOCK:
        print("=" * 56)
        print(f"[PAKET DITERIMA] dari {addr[0]}:{addr[1]} ({ukuran} byte biner)")
        print(f"  Device ID : {data.device_id}")
        print(f"  Timestamp : {data.timestamp} ({waktu})")
        print(f"  Tegangan  : {data.tegangan_volt:.2f} V")
        print(f"  Arus      : {data.arus_ampere:.2f} A")
        print(f"  Status    : {status}")
        print(f"  Log Error : {list(data.log_error) if data.log_error else '-'}")
        if data.status == pb.KRITIS:
            print("  " + "!" * 50)
            print(f"  !!! PERINGATAN KRITIS: sensor {data.device_id} dalam kondisi KRITIS !!!")
            for err in data.log_error:
                print(f"  !!!  -> {err}")
            print("  " + "!" * 50)
        print("=" * 56, flush=True)


def tangani_client(conn: socket.socket, addr) -> None:
    log(f"[+] Client terhubung: {addr[0]}:{addr[1]}")
    try:
        while True:
            payload = recv_msg(conn)
            if payload is None:
                break  # client menutup koneksi

            respon = pb.ResponServer(ukuran_byte=len(payload))
            try:
                data = pb.DataSensor()
                data.ParseFromString(payload)  # deserialisasi
                tampilkan_data(data, len(payload), addr)
                respon.diterima = True
                respon.pesan_konfirmasi = f"Data {data.device_id} berhasil dicatat"
            except DecodeError:
                respon.diterima = False
                respon.pesan_konfirmasi = "Gagal membaca paket: format Protobuf tidak valid"
                log(f"[!] Paket rusak dari {addr[0]}:{addr[1]}")

            send_msg(conn, respon.SerializeToString())  # serialisasi balasan
    except (ConnectionError, ValueError) as e:
        log(f"[!] Error koneksi {addr}: {e}")
    finally:
        conn.close()
        log(f"[-] Client terputus: {addr[0]}:{addr[1]}")


def main():
    ap = argparse.ArgumentParser(description="SmartGrid Telemetry Server")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=5050)
    args = ap.parse_args()

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as srv:
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind((args.host, args.port))
        srv.listen()
        log(f"[*] Server listening di {args.host}:{args.port} (Ctrl+C untuk berhenti)")
        try:
            while True:
                conn, addr = srv.accept()
                threading.Thread(target=tangani_client, args=(conn, addr), daemon=True).start()
        except KeyboardInterrupt:
            log("\n[*] Server dihentikan.")


if __name__ == "__main__":
    main()
