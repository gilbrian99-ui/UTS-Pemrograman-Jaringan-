"""Client SmartGrid Telemetry (TCP Socket + Protocol Buffers).

Jalankan:
  python client.py                     # mode simulasi (4 paket berurutan)
  python client.py --mode interaktif   # input manual dari pengguna
Opsi: --host 127.0.0.1 --port 5050
"""
import argparse
import json
import socket
import time

from google.protobuf.json_format import MessageToDict

import telemetry_pb2 as pb
from common import recv_msg, send_msg


def kirim_paket(sock: socket.socket, data: pb.DataSensor) -> None:
    payload = data.SerializeToString()  # serialisasi -> biner
    ukuran_json = len(json.dumps(MessageToDict(data, preserving_proto_field_name=True)).encode())

    print(f"\n[KIRIM] {data.device_id} | status={pb.StatusPerangkat.Name(data.status)}")
    print(f"        Ukuran Protobuf: {len(payload)} byte  (setara JSON: {ukuran_json} byte)")
    send_msg(sock, payload)

    balasan = recv_msg(sock)
    if balasan is None:
        raise ConnectionError("Server menutup koneksi")
    respon = pb.ResponServer()
    respon.ParseFromString(balasan)  # deserialisasi

    print(f"[BALASAN] diterima : {respon.diterima}")
    print(f"          pesan    : {respon.pesan_konfirmasi}")
    print(f"          ukuran   : {respon.ukuran_byte} byte diterima server "
          f"(terkirim dari client: {len(payload)} byte)")


def buat_data(device_id, tegangan, arus, status, log_error=()):
    d = pb.DataSensor(
        device_id=device_id,
        timestamp=int(time.time()),
        tegangan_volt=tegangan,
        arus_ampere=arus,
        status=status,
    )
    d.log_error.extend(log_error)
    return d


def mode_simulasi(sock):
    paket = [
        buat_data("GD-01", 220.5, 10.2, pb.NORMAL),
        buat_data("GD-02", 198.3, 14.8, pb.PERINGATAN, ["Tegangan di bawah ambang batas"]),
        buat_data("GD-03", 245.9, 32.1, pb.KRITIS,
                  ["Arus berlebih", "Suhu trafo tinggi", "Proteksi gagal aktif"]),
        buat_data("GD-04", 221.0, 9.7, pb.NORMAL),
    ]
    for p in paket:
        kirim_paket(sock, p)
        time.sleep(1)


def mode_interaktif(sock):
    peta = {"0": pb.NORMAL, "1": pb.PERINGATAN, "2": pb.KRITIS}
    while True:
        device_id = input("\nDevice ID (kosongkan untuk keluar): ").strip()
        if not device_id:
            break
        try:
            tegangan = float(input("Tegangan (V): "))
            arus = float(input("Arus (A): "))
        except ValueError:
            print("Input angka tidak valid, ulangi.")
            continue
        status = peta.get(input("Status [0=NORMAL, 1=PERINGATAN, 2=KRITIS]: ").strip(), pb.NORMAL)
        errs = input("Log error (pisahkan dengan koma, boleh kosong): ")
        log_error = [e.strip() for e in errs.split(",") if e.strip()]
        kirim_paket(sock, buat_data(device_id, tegangan, arus, status, log_error))


def main():
    ap = argparse.ArgumentParser(description="SmartGrid Telemetry Client")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=5050)
    ap.add_argument("--mode", choices=["simulasi", "interaktif"], default="simulasi")
    args = ap.parse_args()

    try:
        with socket.create_connection((args.host, args.port), timeout=10) as sock:
            print(f"[*] Terhubung ke server {args.host}:{args.port}")
            (mode_simulasi if args.mode == "simulasi" else mode_interaktif)(sock)
    except ConnectionRefusedError:
        print("[!] Gagal terhubung. Pastikan server.py sudah berjalan.")
    except (ConnectionError, socket.timeout) as e:
        print(f"[!] Error: {e}")
    print("\n[*] Selesai.")


if __name__ == "__main__":
    main()
